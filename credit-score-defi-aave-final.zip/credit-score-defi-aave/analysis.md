# 📊 Credit Score Analysis — Aave V2 Wallets

## 📈 Score Distribution Overview

| Score Range | Wallets Count | Typical Behavior                        |
|-------------|----------------|------------------------------------------|
| 900–1000    | High           | Frequent repayments, low-risk behavior   |
| 700–899     | Moderate       | Mostly repaying, small borrows           |
| 500–699     | Average        | Balanced usage                          |
| 300–499     | Below Avg.     | Irregular activity                      |
| 0–299       | Low            | Liquidations, high risk                 |

## 🧠 Observation
- Top users are disciplined and interact often with deposits + repayments
- Risky users borrow heavily without repaying and get liquidated
