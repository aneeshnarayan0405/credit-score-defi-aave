# 🏦 DeFi Wallet Credit Scoring System — Aave V2

This project assigns a **credit score (0–1000)** to DeFi wallets interacting with the **Aave V2 protocol**, based on their historical transaction behavior (borrow, deposit, repay, etc.).

## 🎯 Objective
Build an ML-based scoring system to classify responsible vs risky users using Aave V2 transaction data.

## 📁 Project Structure
- `/data`: upload the input JSON file here
- `/notebooks`: Jupyter notebooks
- `score_generator.py`: CLI script to generate scores
- `wallet_scores.csv`: credit scores output
- `README.md`, `analysis.md`: explanation and analysis

## 🔍 Features Used
- Action types: deposit, borrow, repay, etc.
- Total/average transaction amount
- USD price and asset diversity

## 💡 Model
Uses PCA + KMeans to cluster wallet behavior and map to scores.

## 📦 How to Run
```bash
python score_generator.py
```

Make sure to place the `user-wallet-transactions.json` in the working directory.

## 📈 Output
- wallet_scores.csv
- top_wallets.csv
- bottom_wallets.csv

## 📬 Author
Aneesh Narayan
